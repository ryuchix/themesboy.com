<?php snippet('header') ?>

<?php snippet('base/content') ?>

<?php snippet('footer') ?>
