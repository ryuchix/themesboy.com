<?php snippet('header') ?>

<?php snippet('resources/content') ?>

<?php snippet('footer') ?>