<?php snippet('header') ?>

<?php snippet('home/content') ?>

<?php snippet('footer') ?>
