<?php snippet('header') ?>

<?php snippet('content') ?>

<?php snippet('footer') ?>
