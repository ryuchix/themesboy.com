<?php

// WARNING: this file is tracked and will be public.
// Use it to give generic examples of the credentials your project uses.

config::set([
  'API.KEY' => 'XX-00000000-0'
]);
