<?php

@include __DIR__ . DS . 'credentials.php';

return [
  'debug' => true,
  'error' => 'error',
];
