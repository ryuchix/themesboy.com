<?= $block->text();
