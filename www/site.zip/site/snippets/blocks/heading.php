<<?= $level = $block->level()->or('h2') ?>>
    <?= $block->text() ?>
</<?= $level ?>>