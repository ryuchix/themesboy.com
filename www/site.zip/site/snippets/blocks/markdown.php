<?= $block->text()->kt();
