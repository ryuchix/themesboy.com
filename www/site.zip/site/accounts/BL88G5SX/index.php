<?php

return [
    'email' => 'evilryok@gmail.com',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];